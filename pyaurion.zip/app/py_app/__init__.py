from flask import Flask  # Import the Flask class
from android.permissions import Permission, request_permissions
request_permissions([Permission.READ_EXTERNAL_STORAGE,Permission.WRITE_EXTERNAL_STORAGE,Permission.INTERNET])

app = Flask(__name__)    # Create an instance of the class for our use

if __name__ == '__main__':
    app.run(debug=False, port=8080)